
    (function($) {
        $(function() {

          $('ul.tabs__caption').on('click', 'li:not(.active)', function() {
            $(this)
              .addClass('active').siblings().removeClass('active')
              .closest('div.tabs').find('div.tabs__content').removeClass('active').eq($(this).index()).addClass('active');
          });

        });
    })(jQuery);
$(document).ready(function(){
    $('.dough').find('img').click(function(){
        var getAtr = $(this).attr('alt');
        $('.dough').find('b').text(getAtr);
    })
    $('.size').find('li').click(function(){
        var getAtr = $(this).attr('class');
        if (getAtr === "XXL") {
            $('.size').find('b').text("30 см");
        } else if (getAtr === "XL"){
            $('.size').find('b').text("25 см");
        }else if (getAtr === "L"){
            $('.size').find('b').text("20 см");
        }
    })
    $('.sauce').find('li').click(function(){
        var getAtr = $(this).attr('class');
         $('.sauce').find('b').text(getAtr);
    })
    
    var spans =  $('.tabs__content').closest('span');
        spans.each(function(){
            var indexElem = spans.index(this);
            $(this).data("eq", indexElem);
            $(this).children('li').data("eq", indexElem);
        });
    var elemsToMove = $('.tabs__content').find('li');
    elemsToMove.click(function(){
           
           var positionElement = $(this).closest('div').attr('id');

           if (positionElement === 'left'){
               $(this).appendTo($(spans.eq($(this).data('eq'))));
               
           } else {
               $('#left').children('ul').append($(this));
           }
           
       });    
})